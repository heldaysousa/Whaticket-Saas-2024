self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "ae294513ca9c0f0d6d57ece563112331",
    "url": "/index.html"
  },
  {
    "revision": "d4fc0556f5d8e4cd5e5a",
    "url": "/static/css/2.0beaeeb3.chunk.css"
  },
  {
    "revision": "a81ec62d7325b91222f7",
    "url": "/static/css/main.901c1384.chunk.css"
  },
  {
    "revision": "d4fc0556f5d8e4cd5e5a",
    "url": "/static/js/2.399e0106.chunk.js"
  },
  {
    "revision": "dfb48c87b2c85417a3fd8b71dbe64a4d",
    "url": "/static/js/2.399e0106.chunk.js.LICENSE.txt"
  },
  {
    "revision": "19b770b3ee6b97ffe70a",
    "url": "/static/js/3.f2fbd62c.chunk.js"
  },
  {
    "revision": "d98f98f9156b1385986c1cdc16f69da5",
    "url": "/static/js/3.f2fbd62c.chunk.js.LICENSE.txt"
  },
  {
    "revision": "a81ec62d7325b91222f7",
    "url": "/static/js/main.1b72ba22.chunk.js"
  },
  {
    "revision": "23ff0dda57516d2151df",
    "url": "/static/js/runtime-main.bd147271.js"
  },
  {
    "revision": "2529c2597bdd5b6559aa1e276d74e930",
    "url": "/static/media/chat_notify.2529c259.mp3"
  },
  {
    "revision": "c75e27c9a280a044f0b39de02ff22bd9",
    "url": "/static/media/email.c75e27c9.png"
  },
  {
    "revision": "325c3d0cfb7292322f9a7e1ecf1be0e7",
    "url": "/static/media/fundo.325c3d0c.mp4"
  },
  {
    "revision": "0b6b3c8d2c74fc2e0be8f5d940ec1e14",
    "url": "/static/media/instagram.0b6b3c8d.png"
  },
  {
    "revision": "b801b20b421f5c72fc24dbb1e9db3ca6",
    "url": "/static/media/logo.b801b20b.png"
  },
  {
    "revision": "5c788b8d54d3ebf021114528116dfd77",
    "url": "/static/media/n8n.5c788b8d.png"
  },
  {
    "revision": "549edebaf5bafe89b539e694d4b1e26c",
    "url": "/static/media/planilha.549edeba.xlsx"
  },
  {
    "revision": "9fd5812c1c2c974cc29e53e138745809",
    "url": "/static/media/sound.9fd5812c.mp3"
  },
  {
    "revision": "786a3db7f3dbf4bbc27efd28d726e6fe",
    "url": "/static/media/success.786a3db7.gif"
  },
  {
    "revision": "8244f0423cb09d847ac99e7546cb9220",
    "url": "/static/media/wa-background-dark.8244f042.png"
  },
  {
    "revision": "adbccee0708ae3b7a71d9652fb353299",
    "url": "/static/media/wa-background.adbccee0.png"
  },
  {
    "revision": "e5374d73ff43538fdaa16a3f1a980f4b",
    "url": "/static/media/webhook.e5374d73.png"
  },
  {
    "revision": "ae8a9a2fbeb676e0a58add382ddea93a",
    "url": "/static/media/whatsapp.ae8a9a2f.png"
  }
]);